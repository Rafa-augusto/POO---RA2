import java.util.ArrayList;

public class Programa {
    public static void main(String[] args){
        ArrayList<Forma> formasGeometricas = new ArrayList<>();
        formasGeometricas.add(new Retangulo(4,5));
        formasGeometricas.add(new Circulo(20));
        for (Forma f : formasGeometricas) {
            System.out.println(f.calcularArea());
        }
    }
}
