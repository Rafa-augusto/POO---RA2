import java.util.ArrayList;
public class Forma {
    public double calcularArea(){
        return 0+0;
    }

}
