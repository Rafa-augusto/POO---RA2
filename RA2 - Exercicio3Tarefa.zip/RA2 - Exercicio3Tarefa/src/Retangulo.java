public class Retangulo extends Forma{
    private double altura;
    private double base;
    public Retangulo(double altura, double base){
        this.altura = altura;
        this.base = base;
    }

    @Override
    public double calcularArea(){
        return altura * base;
    }
}
